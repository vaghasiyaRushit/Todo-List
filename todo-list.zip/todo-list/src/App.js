import React, { useState } from "react";
import "./App.css";

function App() {
  const [userInput, setUserInput] = useState("");
  const [list, setList] = useState([]);
  const [editIndex, setEditIndex] = useState(-1);

  const updateInput = (value) => {
    setUserInput(value);
  };

  const addItem = () => {
    if (userInput.trim() !== "") {
      const userInputData = {
        id: Math.random(),
        value: userInput,
      };

      const updatedList = [...list];
      updatedList.push(userInputData);

      setList(updatedList);
      setUserInput("");
    }
  };

  const deleteItem = (key) => {
    const updatedList = list.filter((item) => item.id !== key);
    setList(updatedList);
  };

  const editItem = (index) => {
    setEditIndex(index);
    setUserInput(list[index].value);
  };

  const saveEditedItem = (index) => {
    const updatedList = [...list];
    updatedList[index].value = userInput;
    setList(updatedList);
    setEditIndex(-1);
    setUserInput("");
  };

  return (
    <div>
      <h1>TODO LIST</h1>
      <hr />
      <div>
        <input
          placeholder="add item . . . "
          value={userInput}
          onChange={(e) => updateInput(e.target.value)}
        />
        <button onClick={addItem}>ADD</button>
      </div>
      <div>
        {list.map((item, index) => (
          <div key={item.id}>
            {editIndex === index ? (
              <input
                value={userInput}
                onChange={(e) => updateInput(e.target.value)}
              />
            ) : (
              <span>{item.value}</span>
            )}
            <span>
              {editIndex === index ? (
                <button onClick={() => saveEditedItem(index)}>Save</button>
              ) : (
                <button onClick={() => editItem(index)}>Edit</button>
              )}
              <button onClick={() => deleteItem(item.id)}>Delete</button>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
